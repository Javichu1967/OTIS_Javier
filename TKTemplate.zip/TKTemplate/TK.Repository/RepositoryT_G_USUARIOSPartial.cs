﻿using System.Linq;
using TK.Domain;

namespace $safeprojectname$
{
    public partial class RepositoryT_G_USUARIOS
    {

        public IQueryable<T_G_USUARIOS> GetUser(string logon)
        {
            return Fetch()
                .Where(x => x.B_ACTIVO)
                .Where(x => x.LOGIN.ToUpper().Equals(logon.ToUpper()));

        }


    }
}
