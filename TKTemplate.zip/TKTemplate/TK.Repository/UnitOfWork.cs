using System;
using TK.Domain;
using System.Transactions;

namespace $safeprojectname$
{
    public partial class UnitOfWork :  IUnitOfWork, IDisposable
    {

				ModelEntities _context_ModelEntities = null;
        private  ModelEntities context_ModelEntities
        {
            get
            {
                if (_context_ModelEntities == null)
                    _context_ModelEntities = new ModelEntities();
					_context_ModelEntities.Database.Log = s => System.Diagnostics.Debug.WriteLine(s);					
                return _context_ModelEntities;
            }
        }

		 #region Repositories
	
			private IRepositoryT_G_MENUS repositoryT_G_MENUS;
			  
			public IRepositoryT_G_MENUS RepositoryT_G_MENUS
			{
				get
				{

					if (repositoryT_G_MENUS == null)
					{
						repositoryT_G_MENUS = new RepositoryT_G_MENUS(context_ModelEntities);
					}
					return repositoryT_G_MENUS;
				}
			}

		
			private IRepositoryT_G_USUARIOS repositoryT_G_USUARIOS;
			  
			public IRepositoryT_G_USUARIOS RepositoryT_G_USUARIOS
			{
				get
				{

					if (repositoryT_G_USUARIOS == null)
					{
						repositoryT_G_USUARIOS = new RepositoryT_G_USUARIOS(context_ModelEntities);
					}
					return repositoryT_G_USUARIOS;
				}
			}

		
			private IRepositoryT_G_USUARIOS_CECO repositoryT_G_USUARIOS_CECO;
			  
			public IRepositoryT_G_USUARIOS_CECO RepositoryT_G_USUARIOS_CECO
			{
				get
				{

					if (repositoryT_G_USUARIOS_CECO == null)
					{
						repositoryT_G_USUARIOS_CECO = new RepositoryT_G_USUARIOS_CECO(context_ModelEntities);
					}
					return repositoryT_G_USUARIOS_CECO;
				}
			}

		
			private IRepositoryT_G_USUARIOS_DELEGACION repositoryT_G_USUARIOS_DELEGACION;
			  
			public IRepositoryT_G_USUARIOS_DELEGACION RepositoryT_G_USUARIOS_DELEGACION
			{
				get
				{

					if (repositoryT_G_USUARIOS_DELEGACION == null)
					{
						repositoryT_G_USUARIOS_DELEGACION = new RepositoryT_G_USUARIOS_DELEGACION(context_ModelEntities);
					}
					return repositoryT_G_USUARIOS_DELEGACION;
				}
			}

		
			private IRepositoryT_G_USUARIOS_DIR_TERRITORIAL repositoryT_G_USUARIOS_DIR_TERRITORIAL;
			  
			public IRepositoryT_G_USUARIOS_DIR_TERRITORIAL RepositoryT_G_USUARIOS_DIR_TERRITORIAL
			{
				get
				{

					if (repositoryT_G_USUARIOS_DIR_TERRITORIAL == null)
					{
						repositoryT_G_USUARIOS_DIR_TERRITORIAL = new RepositoryT_G_USUARIOS_DIR_TERRITORIAL(context_ModelEntities);
					}
					return repositoryT_G_USUARIOS_DIR_TERRITORIAL;
				}
			}

		
			private IRepositoryT_G_USUARIOS_EMPRESAS repositoryT_G_USUARIOS_EMPRESAS;
			  
			public IRepositoryT_G_USUARIOS_EMPRESAS RepositoryT_G_USUARIOS_EMPRESAS
			{
				get
				{

					if (repositoryT_G_USUARIOS_EMPRESAS == null)
					{
						repositoryT_G_USUARIOS_EMPRESAS = new RepositoryT_G_USUARIOS_EMPRESAS(context_ModelEntities);
					}
					return repositoryT_G_USUARIOS_EMPRESAS;
				}
			}

		
			private IRepositoryT_M_PERFILES repositoryT_M_PERFILES;
			  
			public IRepositoryT_M_PERFILES RepositoryT_M_PERFILES
			{
				get
				{

					if (repositoryT_M_PERFILES == null)
					{
						repositoryT_M_PERFILES = new RepositoryT_M_PERFILES(context_ModelEntities);
					}
					return repositoryT_M_PERFILES;
				}
			}

		
			private IRepositoryT_R_PERFILES_MENU repositoryT_R_PERFILES_MENU;
			  
			public IRepositoryT_R_PERFILES_MENU RepositoryT_R_PERFILES_MENU
			{
				get
				{

					if (repositoryT_R_PERFILES_MENU == null)
					{
						repositoryT_R_PERFILES_MENU = new RepositoryT_R_PERFILES_MENU(context_ModelEntities);
					}
					return repositoryT_R_PERFILES_MENU;
				}
			}

		 
		
		#endregion
		

        public void Commit()
        {
            context_ModelEntities.SaveChanges();
        }

        public bool LazyLoadingEnabled
        {
            get { return context_ModelEntities.Configuration.LazyLoadingEnabled; }
            set { context_ModelEntities.Configuration.LazyLoadingEnabled = value; }
        }

        public bool ProxyCreationEnabled
        {
            get { return context_ModelEntities.Configuration.ProxyCreationEnabled; }
            set { context_ModelEntities.Configuration.ProxyCreationEnabled = value; }
        }

        public string ConnectionString
        {
            get { return context_ModelEntities.Database.Connection.ConnectionString; }
            set { context_ModelEntities.Database.Connection.ConnectionString = value; }
        }

		
		TransactionScope _transaction;
        public void BeginTransaction()
        {
            _transaction = new TransactionScope();
        }

        public void CompleteTransaction()
        {           
            _transaction.Complete();
        }

        private bool disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    context_ModelEntities.Dispose();
					 if (_transaction != null)
                        _transaction.Dispose();
                }
            }
            this.disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
 
  
