using TK.Domain;
 
    
namespace $safeprojectname$
{   
    public partial class RepositoryT_R_PERFILES_MENU : RepositoryBase<T_R_PERFILES_MENU>, IRepositoryT_R_PERFILES_MENU
    {
		public RepositoryT_R_PERFILES_MENU(ModelEntities context)
            : base(context)
        {

        }
    }
}