 
     
namespace $safeprojectname$
{   
    public partial interface IRepositoryT_G_USUARIOS_EMPRESAS : IRepositoryBase<T_G_USUARIOS_EMPRESAS>
    {
		 
		 
    }
}