﻿using System.Linq;

namespace $safeprojectname$
{
    public partial interface IRepositoryT_G_USUARIOS
    {
        IQueryable<T_G_USUARIOS> GetUser(string logon);
    }
}
