 
     
namespace $safeprojectname$
{   
    public partial interface IRepositoryT_G_USUARIOS_CECO : IRepositoryBase<T_G_USUARIOS_CECO>
    {
		 
		 
    }
}