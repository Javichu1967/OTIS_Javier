 
     
namespace $safeprojectname$
{   
    public partial interface IRepositoryT_G_USUARIOS_DELEGACION : IRepositoryBase<T_G_USUARIOS_DELEGACION>
    {
		 
		 
    }
}