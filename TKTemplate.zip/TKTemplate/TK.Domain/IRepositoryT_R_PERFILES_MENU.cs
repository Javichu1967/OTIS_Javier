 
     
namespace $safeprojectname$
{   
    public partial interface IRepositoryT_R_PERFILES_MENU : IRepositoryBase<T_R_PERFILES_MENU>
    {
		 
		 
    }
}