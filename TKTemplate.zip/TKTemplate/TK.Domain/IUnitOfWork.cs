
namespace $safeprojectname$
{
    public partial interface IUnitOfWork
    {
         
        void Commit();
		void BeginTransaction();
		void CompleteTransaction();
        bool LazyLoadingEnabled { get; set; }
        bool ProxyCreationEnabled { get; set; }
        string ConnectionString { get; set; }
				IRepositoryT_G_MENUS RepositoryT_G_MENUS { get; }
           
		IRepositoryT_G_USUARIOS RepositoryT_G_USUARIOS { get; }
           
		IRepositoryT_G_USUARIOS_CECO RepositoryT_G_USUARIOS_CECO { get; }
           
		IRepositoryT_G_USUARIOS_DELEGACION RepositoryT_G_USUARIOS_DELEGACION { get; }
           
		IRepositoryT_G_USUARIOS_DIR_TERRITORIAL RepositoryT_G_USUARIOS_DIR_TERRITORIAL { get; }
           
		IRepositoryT_G_USUARIOS_EMPRESAS RepositoryT_G_USUARIOS_EMPRESAS { get; }
           
		IRepositoryT_M_PERFILES RepositoryT_M_PERFILES { get; }
           
		IRepositoryT_R_PERFILES_MENU RepositoryT_R_PERFILES_MENU { get; }
           


    }
}
 
  
