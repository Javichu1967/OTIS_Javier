 
     
namespace $safeprojectname$
{   
    public partial interface IRepositoryT_G_MENUS : IRepositoryBase<T_G_MENUS>
    {
		 
		 
    }
}