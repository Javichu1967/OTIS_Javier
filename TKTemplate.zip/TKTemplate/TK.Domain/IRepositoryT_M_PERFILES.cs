 
     
namespace $safeprojectname$
{   
    public partial interface IRepositoryT_M_PERFILES : IRepositoryBase<T_M_PERFILES>
    {
		 
		 
    }
}