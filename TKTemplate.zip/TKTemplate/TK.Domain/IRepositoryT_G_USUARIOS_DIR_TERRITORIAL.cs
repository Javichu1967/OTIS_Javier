 
     
namespace $safeprojectname$
{   
    public partial interface IRepositoryT_G_USUARIOS_DIR_TERRITORIAL : IRepositoryBase<T_G_USUARIOS_DIR_TERRITORIAL>
    {
		 
		 
    }
}