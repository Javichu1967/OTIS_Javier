﻿using log4net;
using System;
using System.Configuration;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using System.Security.Principal;
using $safeprojectname$.Application_Services;
using TKSeguridad;

namespace $safeprojectname$
{
    public class MvcApplication : System.Web.HttpApplication
    {
        readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            // Register TK Resources
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            
            
            var path = Server.MapPath(ConfigurationManager.AppSettings["PathLog4net"]);


            log4net.Config.XmlConfigurator.Configure(new System.IO.FileInfo(path));

    
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            Exception exception = Server.GetLastError();
            logger.Error(exception);
            Server.ClearError();
            if (exception.GetType() == typeof(HttpException) && ((HttpException)exception).GetHttpCode() == 404)
            {
                Response.Redirect("~/Error/NotFound");//o por custom error
            }
            else
            {

                Response.Redirect("~/Error/Index");
            }
        }

        protected void Session_Start(object sender, EventArgs e)
        {

             if (!Request.IsLocal && (ConfigurationManager.AppSettings["appCode"] != null || ConfigurationManager.AppSettings["appCode"] != "9999"))
            {
                if (TKSeguridadWeb.ChequeaAutorizacionEntrada(ConfigurationManager.AppSettings["appCode"]) == false)
                {
                    Response.Redirect(TKSeguridadWeb.PaginaNoAutorizacion);
                    return;
                }
            }


        }
    }


}
