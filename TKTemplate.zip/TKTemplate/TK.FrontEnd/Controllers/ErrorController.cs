﻿using System.Web.Mvc;
namespace $safeprojectname$.Controllers
{
   
    public class ErrorController : Controller
    {       
        public ViewResult NotFound()
        {
            return View();
        }

        public ViewResult EntityExpception()
        { 
            return View();
        }

        public ViewResult Index()
        {
            return View("Error");
        }

        public ViewResult UnauthorizedAccess()
        {
            return View();
        }

        public ViewResult UnauthorizedBrowser()
        {
            return View();
        }

    }
}
