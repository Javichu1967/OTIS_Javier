﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Models;
using TKUtilidades;

namespace $safeprojectname$.Controllers
{
    [AuthorizeUser]
    public class BaseController : Controller
    {
        public UserModel UserModel
        {
            get
            {
                return (UserModel)Util.GetItemFromMemory("userProfile");
            }
        }
    }
}