﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using $safeprojectname$.Application_Services;
using $safeprojectname$.Models;
using TKUtilidades;

namespace $safeprojectname$.Controllers
{
    
    public class HomeController : BaseController
    {
        public ActionResult Index()
        {         
            return View();
        }


        public FileResult DescargarPDF()
        {

            string filename = System.Configuration.ConfigurationManager.AppSettings["userManual"];

            string contentType = "application/pdf";

            var path = Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["pathManual"]);

            var fileNameServer = System.IO.Path.Combine(path, filename);


            return File(fileNameServer, contentType, filename);
        }
        
        /// <summary>
        /// Añade los datos al modal de "Abrir incidencia"
        /// </summary>
        /// <returns></returns>
        public ActionResult AbrirIncidencia()
        {
            SapHrWebApiService servApi = new SapHrWebApiService();

            UserModel user = (UserModel)Util.GetItemFromMemory("userProfile");

            IncidenciaModel model = new IncidenciaModel
            {
                LoginUsuario = user.Login,
                NombreUsuario = user.Nombre,
                CorreoUsuario = user.Email != null && user.Email != "" ? user.Email : servApi.obtenerCorreoUsuario(user.Login),
                NombreAplicacion = System.Configuration.ConfigurationManager.AppSettings["appname"].ToString(),
                CodigoAplicacion = System.Configuration.ConfigurationManager.AppSettings["appCode"].ToString(),
                CorreoCAU = System.Configuration.ConfigurationManager.AppSettings["correoCAU"].ToString()
            };

            return PartialView("_DatosIncidencia", model);
        }

        /// <summary>
        /// Obtenemos los datos del formulario "AbrirIncidencia" y si son correctos enviamos email
        /// </summary>
        /// <param name="form"></param>
        /// <returns></returns>
        public ActionResult ComprobarDatosIncidencia(FormCollection form)
        {
            string resultado = "";
            EmailService emailServ = new EmailService();

            var loginUsuario = form["LoginUsuario"] != null ? form["LoginUsuario"] : "";
            var nombreUsuario = form["NombreUsuario"] != null ? form["NombreUsuario"] : "";
            var correoUsuario = form["CorreoUsuario"] != null ? form["CorreoUsuario"] : "";
            var correoCAU = form["CorreoCAU"] != null ? form["CorreoCAU"] : "";
            var nombreApp = form["NombreAplicacion"] != null ? form["NombreAplicacion"] : "";
            var codigoApp = form["CodigoAplicacion"] != null ? form["CodigoAplicacion"] : "";
            var descripcionIncidencia = form["DescripcionIncidencia"] != null ? form["DescripcionIncidencia"] : "";
            var descripcion = descripcionIncidencia.Length > 0 ? descripcionIncidencia.Substring(0, descripcionIncidencia.Length - 1) : "";

            if (descripcion == null || descripcion.Trim() == "")
            {
                return Json("FaltaComentario");
            }

            if (Request != null)
            {
                HttpPostedFileBase file = Request.Files["FileToImport"];

                if ((file != null) && (file.ContentLength > 0) && !string.IsNullOrEmpty(file.FileName))
                {
                    //ruta de nuestros archivos
                    string rutaArchivos = Server.MapPath(System.Configuration.ConfigurationManager.AppSettings["rutaArchivos"]);

                    //si no existe el directorio lo creamos
                    if (!Directory.Exists(rutaArchivos))
                    {
                        DirectoryInfo di = Directory.CreateDirectory(rutaArchivos);
                    }

                    //guardamos el archivo
                    file.SaveAs(rutaArchivos + file.FileName);

                    resultado = emailServ.EnviarEmail(loginUsuario, nombreUsuario, correoUsuario, correoCAU, codigoApp, nombreApp, descripcion, rutaArchivos + file.FileName);

                    //finalmente obtenemos el archivo del directorio y lo borramos
                    string[] filePaths = Directory.GetFiles(rutaArchivos);

                    foreach (string filePath in filePaths)
                    {
                        System.IO.File.Delete(filePath);
                    }

                    return Json(resultado);
                }
                else
                {
                    //Enviamos el correo sin adjuntos
                    resultado = emailServ.EnviarEmail(loginUsuario, nombreUsuario, correoUsuario, correoCAU, codigoApp, nombreApp, descripcion, "");
                    return Json(resultado);
                }
            }
            else
            {
                return Json("Error");
            }
        }



    }


}
