﻿using System;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Threading;
using System.Web.Mvc;
using System.Web;
using System.Web.Routing;
using System.Collections.Generic;
using System.Linq;
using $safeprojectname$.Application_Services;
using TKUtilidades;
using System.Security.Principal;
using $safeprojectname$.Models;

namespace $safeprojectname$
{
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false, Inherited = true)]
    public class AuthorizeUserAttribute : AuthorizeAttribute
    {

        private Boolean NavegadorCompatible = true;
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {

            UserModel user = (UserModel)Util.GetItemFromMemory("userProfile");
            if (user == null)
            {
                var userService = new UsersService();

                var username = httpContext.User.Identity.Name.Split('\\').Last();

                user = userService.GetUser(username);


                Util.AddItemToMemory("userProfile", user);
            }

            //Comprobamos si el usuario esta accediendo con IE 6, 7 u 8
            if ((httpContext.Request.Browser.Browser == "InternetExplorer" || httpContext.Request.Browser.Browser == "IE") && (httpContext.Request.Browser.Version.Contains("6") || httpContext.Request.Browser.Version.Contains("7") || httpContext.Request.Browser.Version.Contains("8")))
            {               
                //Con IE 11 devuelve Browser.Version = 7 y Browser.Browser IE y el Request.UserAgent es Trident/7
                //Con IE 7 Browser.Version = 7
                //Trident/7 = IE 11, Trident/6 = IE 10, Trident/5 = IE 9, and Trident/4 = IE 8
                //Verificamos que no es IE 11, ya que tiene el mismo numero de version el IE7 y el IE11
                if (!(httpContext.Request.UserAgent.Contains(@"Trident/7") && httpContext.Request.Browser.Version.Contains("7")))
                {
                    NavegadorCompatible = false;
                    return false;
                }
            }

            return user != null ? true : false;

        }


        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (!NavegadorCompatible)
            {
                filterContext.Result = new RedirectToRouteResult(
                new RouteValueDictionary(
                new
                {
                    controller = "Error",
                    action = "UnauthorizedBrowser"
                })
                );
            }
            else
            {
                filterContext.Result = new RedirectToRouteResult(
                new RouteValueDictionary(
                new
                {
                    controller = "Error",
                    action = "UnauthorizedAccess"
                })
                );
            }
        }
    }


}
