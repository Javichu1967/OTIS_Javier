﻿using System;
using System.Web.Mvc;
using log4net;
using System.Net;
using System.Web.Routing;
using System.Web;

namespace $safeprojectname$
{

    public class HandleCustomException : HandleErrorAttribute
    {
        readonly ILog logger = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public override void OnException(ExceptionContext filterContext)
        {

            if (!ExceptionType.IsInstanceOfType(filterContext.Exception))
            {
                return;
            }
            logger.Error(filterContext.Exception);

            filterContext.HttpContext.Response.Clear();

            filterContext.ExceptionHandled = true;

            if (filterContext.HttpContext.Request.IsAjaxRequest())//es una petición ajax
            {
                filterContext.Result = new JsonResult()
                {
                    Data = filterContext.Exception.Message,

                    JsonRequestBehavior = JsonRequestBehavior.AllowGet
                };
                filterContext.HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            }
            else
            {
                var typeexception = filterContext.Exception.GetType();

                //es un error de base de datos
                if (typeexception == (typeof(System.Data.Entity.Core.EntityException)))
                {

                    

                    ExecuteCustomViewResult(filterContext.Controller, "~/Views/Error/EntityExpception.cshtml");
                }
                if (typeexception == typeof(HttpException) && ((HttpException)filterContext.Exception).GetHttpCode() == (int)HttpStatusCode.NotFound)
                {
                    ExecuteCustomViewResult(filterContext.Controller, "~/Views/Error/NotFound.cshtml");
                }
                else
                {//otro tipo de excepción

                    var controllerName = (string)filterContext.RouteData.Values["controller"];
                    var actionName = (string)filterContext.RouteData.Values["action"];
                    //si queremos mostrar un modelo de errores en la página
                    var model = new HandleErrorInfo(filterContext.Exception, controllerName, actionName);

                    ExecuteCustomViewResult(filterContext.Controller, "~/Views/Shared/Error.cshtml");
                    

                }

                
            }

        }
        void ExecuteCustomViewResult(ControllerBase controller, string viewName)
        {
            ViewResult viewResult = new ViewResult();
            viewResult.ViewName = viewName;
            viewResult.ViewData = controller.ViewData;
            viewResult.TempData = controller.TempData;
            viewResult.ExecuteResult(controller.ControllerContext);
            controller.ControllerContext.HttpContext.Response.TrySkipIisCustomErrors = true;
        }

        
    }
}
