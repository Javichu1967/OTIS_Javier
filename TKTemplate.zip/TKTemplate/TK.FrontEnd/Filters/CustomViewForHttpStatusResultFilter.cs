﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$
{
    public class CustomViewForHttpStatusResultFilter : IResultFilter
    {
        string viewName;
        int statusCode;

        public CustomViewForHttpStatusResultFilter(HttpStatusCodeResult prototype, string viewName)
            : this(prototype.StatusCode, viewName)
        {
        }

        public CustomViewForHttpStatusResultFilter(int statusCode, string viewName)
        {
            this.viewName = viewName;
            this.statusCode = statusCode;
        }

        public void OnResultExecuted(ResultExecutedContext filterContext)
        {
            HttpStatusCodeResult httpStatusCodeResult = filterContext.Result as HttpStatusCodeResult;

            if (httpStatusCodeResult != null && httpStatusCodeResult.StatusCode == statusCode)
            {
                ExecuteCustomViewResult(filterContext.Controller.ControllerContext);

            }
        }

        public void OnResultExecuting(ResultExecutingContext filterContext)
        {           
        }



        void ExecuteCustomViewResult(ControllerContext controllerContext)
        {
            ViewResult viewResult = new ViewResult();
            viewResult.ViewName = viewName;
            viewResult.ViewData = controllerContext.Controller.ViewData;
            viewResult.TempData = controllerContext.Controller.TempData;
            viewResult.ExecuteResult(controllerContext);
            controllerContext.HttpContext.Response.TrySkipIisCustomErrors = true;
        }
    }
}