﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{


    public class FuncionesSAPHRModel
    {
        public int IdFuncion { get; set; }
        public string Funcion { get; set; }
        public string Email { get; set; }
    }
}