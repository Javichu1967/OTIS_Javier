﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Models
{
    public class UserModel
    {
        public string Login { get; set; }

        public string Nombre { get; set; }

        public string Email { get; set; }

        public int IdPerfil { get; set; }

        public string IdDT { get; set; }

        public string IdDelegacion { get; set; }
        public IEnumerable<CecosModel> CecosModelList { get; set; }

        public IEnumerable<MenuModel> OpcionesMenu { get; set; }

    }

    public class CecosModel
    {
        public int CodigoEmpresa { get; set; }

        public string Empresa { get; set; }

        public string IdDT { get; set; }

        public string DireccionTerritorial { get; set; }

        public string IdDelegacion { get; set; }

        public string Delegacion { get; set; }

        public string IdCeco { get; set; }

        public string Ceco { get; set; }

        public string IdCecoFormatted { get; set; }

    }

    public class MenuModel
    {
        public int idMenu { get; set; }
        public string Descripcion { get; set; }
        public int? idMenuPadre { get; set; }
        public string Action { get; set; }
        public string Controller { get; set; }
        public bool Activo { get; set; }
        public List<MenuModel> ListaMenu { get; set; }
    }

    public class UsuariosModel
    {
        public string Nombre { get; set; }

        [ReadOnly(true)]
        public string NombreCompleto { get; set; }
        
        public string Email { get; set; }
        public int CodigoEmpresa { get; set; }

        public string Empresa { get; set; }

        public string IdDT { get; set; }

        public string DireccionTerritorial { get; set; }

        public string IdDelegacion { get; set; }

        public string Delegacion { get; set; }

        public string IdCeco { get; set; }

        public string Ceco { get; set; }

        public int? IdDA { get; set; }

        public string DA { get; set; }

        public string IdFuncion { get; set; }

        public string Funcion { get; set; }

        public string Login { get; set; }

        public string Añadido { get; set; }

        public int NumeroEmpleado { get; set; }

        public string Accion { get; set; }

        public DateTime FechaDato { get; set; }

    }
}