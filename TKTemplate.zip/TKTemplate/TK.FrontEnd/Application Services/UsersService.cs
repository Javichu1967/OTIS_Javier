﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TK.Domain;
using $safeprojectname$.Models;
using TK.Repository;

namespace $safeprojectname$.Application_Services
{
    public class UsersService
    {
        public class userInfo
        {
            public string Login { get; set; }

            public int IdPerfil { get; set; }

            public string Nombre { get; set; }

            public string Email { get; set; }

            public string Dni { get; set; }

            public IEnumerable<int> Empresas { get; set; }

            public IEnumerable<string> DireccionesTerritoriales { get; set; }

            public IEnumerable<string> Delegaciones { get; set; }

            public IEnumerable<string> Cecos { get; set; }

            public IEnumerable<MenuUser> Menus { get; set; }

            public class FuncionModel
            {
                public int IdFuncion { get; set; }
                public string Funcion { get; set; }
            }

        }
        public class MenuUser
        {
            public string Descripcion { get; set; }
            public int idMenu { get; set; }
            public int? idMenuPadre { get; set; }
            public string Action { get; set; }
            public string Controller { get; set; }
            public bool Activo { get; set; }
        }

        public UserModel GetUser(string logon)
        {
            UserModel userModel = null;

            using (var unitOfWork = new UnitOfWork())
            {

                //if (unitOfWork.RepositorySAPHR_UsuariosSAP.ExistUserInSAP(logon))
                //{
                var userInfo = (from user in unitOfWork.RepositoryT_G_USUARIOS.GetUser(logon)
                                select new userInfo
                                {
                                    Login = user.LOGIN,

                                    IdPerfil = user.ID_PERFIL,

                                    Email = user.EMAIL,

                                    Nombre = user.NOMBRE,

                                    Empresas = (from empresa in user.T_G_USUARIOS_EMPRESAS
                                                select empresa.ID_EMPRESA),

                                    DireccionesTerritoriales = (from dir in user.T_G_USUARIOS_DIR_TERRITORIAL
                                                                select dir.ID_DT),

                                    Delegaciones = (from delegacion in user.T_G_USUARIOS_DELEGACION
                                                    select delegacion.ID_DELEGACION),

                                    Cecos = (from ceco in user.T_G_USUARIOS_CECO
                                             select ceco.ID_CECO),

                                    Menus = (from menu in user.T_M_PERFILES.T_R_PERFILES_MENU
                                             where menu.B_ACTIVO
                                             where user.T_M_PERFILES.B_ACTIVO
                                             orderby menu.T_G_MENUS.ORDEN
                                             select new MenuUser
                                             {
                                                 Descripcion = menu.T_G_MENUS.DESCRIPCION,
                                                 idMenu = menu.ID_MENU,
                                                 idMenuPadre = menu.T_G_MENUS.ID_MENU_PARENT,
                                                 Action = menu.T_G_MENUS.ACTION,
                                                 Controller = menu.T_G_MENUS.CONTROLLER,
                                                 Activo = menu.B_ACTIVO
                                             })


                                }).SingleOrDefault();


                if (userInfo != null)
                {//completamos su configuración a donde corresponda.
                 //setConfiguracionSecurity(unitOfWork, userInfo);

                    userModel = new UserModel
                    {
                        Login = userInfo.Login,

                        IdPerfil = userInfo.IdPerfil,

                        Email = userInfo.Email,

                        Nombre = userInfo.Nombre,

                        //Dni = userInfo.Dni,

                        //CecosModelList = getCecosModelUser(unitOfWork, userInfo.Cecos),

                        OpcionesMenu = (from menu in userInfo.Menus
                                        select new MenuModel
                                        {
                                            idMenu = menu.idMenu,
                                            Descripcion = menu.Descripcion,
                                            idMenuPadre = menu.idMenuPadre,
                                            Action = menu.Action,
                                            Controller = menu.Controller,
                                            Activo = menu.Activo
                                        }).ToList()

                    };


                }


                //}

            }

            userModel.OpcionesMenu = GetMenuTree(userModel.OpcionesMenu.ToList(), null);

            return userModel;

        }



        //private void setConfiguracionSecurity(IUnitOfWork unitOfWork, userInfo userInfo)
        //{
        //    if (!userInfo.Empresas.Any())
        //    {
        //        //configuración desde sap
        //        setConfiguracionSAP(unitOfWork, userInfo);

        //    }

        //    //comprobamos que tiene dir. territoriales
        //    if (!userInfo.DireccionesTerritoriales.Any())
        //    {
        //        //nos traemos las dir.territorial de las empresas
        //        //si es una empresa diferente a la 8100 no tendrá dir. territorial
        //        setDireccionesTerritorialesUser(unitOfWork, userInfo);
        //    }
        //    //comprobamos que tiene delegaciones
        //    if (!userInfo.Delegaciones.Any())
        //    {
        //        //nos traemos las delegaciones de su dirrección territorial o de sus empresas
        //        // si no tuviera dirrección territorial
        //        setDelegacionesUser(unitOfWork, userInfo);
        //    }
        //    //comprobamos que tiene cecos
        //    if (!userInfo.Cecos.Any())
        //    {
        //        //nos traemos los cecos de sus delegaciones  
        //        setCecosUser(unitOfWork, userInfo);
        //    }
        //}

        //private void setConfiguracionSAP(IUnitOfWork unitOfWork, userInfo userInfo)
        //{
        //    var esDelegadoZona = userInfo.IdPerfil == (int)EnumTipoPerfil.DelegadoZona;
        //    if (esDelegadoZona)
        //    {
        //        //si es delegado de zona y tiene config. de zonas
        //        esDelegadoZona = setConfigDelegadoZonaUser(unitOfWork, userInfo);
        //    }


        //    if (!esDelegadoZona)
        //    {//Configuración por defecto de sap 
        //        var userSap = unitOfWork.RepositorySAPHR_UsuariosSAP.FindOne(x => x.Logon.ToUpper().Equals(userInfo.Login));

        //        userInfo.Empresas = new List<int> { userSap.CodigoEmpresa };

        //        //El superUsuario hasta el nivel de empresas
        //        //El dir. territorial , controller y delegado de zona  hasta el nivel de dir. territorial
        //        //Administrativo   hasta el nivel de delegacion  

        //        if (!string.IsNullOrEmpty(userSap.IdDT) && userInfo.IdPerfil != (int)EnumTipoPerfil.SuperUsuario)
        //        {
        //            userInfo.DireccionesTerritoriales = new List<string> { userSap.IdDT };
        //        }

        //        if (!string.IsNullOrEmpty(userSap.IdDelegacion) &&
        //                userInfo.IdPerfil != (int)EnumTipoPerfil.DirectorTerritorial &&
        //                userInfo.IdPerfil != (int)EnumTipoPerfil.Controller &&
        //                userInfo.IdPerfil != (int)EnumTipoPerfil.DelegadoZona)
        //        {
        //            userInfo.Delegaciones = new List<string> { userSap.IdDelegacion };
        //        }
        //    }
        //}

        //private void setDireccionesTerritorialesUser(IUnitOfWork unitOfWork, userInfo userInfo)
        //{

        //    userInfo.DireccionesTerritoriales = unitOfWork.RepositorySAPHR_DireccionesTerritoriales
        //        .GetDirrecionesTerritorialesByEmpresas(userInfo.Empresas)
        //        .Select(x => x.IdDT)
        //        .ToList();
        //}

        //private void setDelegacionesUser(IUnitOfWork unitOfWork, userInfo userInfo)
        //{
        //    userInfo.Delegaciones = unitOfWork.RepositorySAPHR_Delegaciones
        //        .GetDelegacionesByEmpresasOrDT(userInfo.Empresas, userInfo.DireccionesTerritoriales)
        //         .Select(x => x.IdDelegacion)
        //        .ToList();

        //}

        //private void setCecosUser(IUnitOfWork unitOfWork, userInfo userInfo)
        //{

        //    userInfo.Cecos = unitOfWork.RepositorySAPHR_CentrosCoste
        //        .GetCecosByDelegaciones(userInfo.Delegaciones, userInfo.Empresas, userInfo.DireccionesTerritoriales)
        //        .Select(x => x.IdCeco)
        //            .ToList();

        //}

        /// <summary>
        /// Devuelve TRUE si tiene una configuración por zona en caso contrario FALSE.
        /// </summary>
        /// <param name="unitOfWork"></param>
        /// <param name="userModel"></param>
        /// <returns></returns>
        //private bool setConfigDelegadoZonaUser(IUnitOfWork unitOfWork, userInfo userInfo)
        //{


        //    var delegacionesSap = (from delegacion in unitOfWork.RepositorySAPHR_Delegaciones.GetDelegacionesByUserZona(userInfo.Login)
        //                           select new
        //                           {
        //                               delegacion.IdDelegacion,
        //                               delegacion.IdDT,
        //                               delegacion.Empresa
        //                           }).ToList();
        //    bool hasConfigZona = delegacionesSap.Any();

        //    if (hasConfigZona)
        //    {

        //        userInfo.Empresas = delegacionesSap.Select(x => x.Empresa).Distinct().ToList();

        //        userInfo.DireccionesTerritoriales = delegacionesSap.Where(x => !string.IsNullOrEmpty(x.IdDT)).Select(x => x.IdDT).Distinct().ToList();

        //        userInfo.Delegaciones = delegacionesSap.Where(x => !string.IsNullOrEmpty(x.IdDelegacion)).Select(x => x.IdDelegacion).Distinct().ToList();
        //    }

        //    return hasConfigZona;
        //}

        //private List<CecosModel> getCecosModelUser(IUnitOfWork unitOfWork, IEnumerable<string> cecos)
        //{
        //    var cecosList = (from ceco in unitOfWork.RepositorySAPHR_CentrosCoste.GetCecos(cecos)
        //                     select new CecosModel
        //                     {
        //                         CodigoEmpresa = ceco.Empresa,
        //                         IdDelegacion = ceco.IdDelegacion,
        //                         IdDT = ceco.IdDT,
        //                         IdCeco = ceco.IdCeco,
        //                         IdCecoFormatted = ceco.IdCeco,
        //                         Ceco = ceco.Nombre,
        //                         Empresa = ceco.SAPHR_Empresas.Nombre,
        //                         Delegacion = ceco.SAPHR_Delegaciones.Nombre,
        //                         DireccionTerritorial = ceco.SAPHR_DireccionesTerritoriales.Nombre
        //                     }).ToList();

        //    cecosList.ForEach(x => x.IdCeco = x.IdCeco.TrimStart('0'));

        //    return cecosList;


        //}

        public List<MenuModel> GetMenuTree(List<MenuModel> list, int? padre)
        {
            var menu = list.Where(x => x.idMenuPadre == padre).Select(x => new MenuModel
            {
                idMenu = x.idMenu,
                Descripcion = x.Descripcion,
                idMenuPadre = x.idMenuPadre,
                Activo = x.Activo,
                Action = x.Action,
                Controller = x.Controller,
                ListaMenu = GetMenuTree(list, x.idMenu)
            }).ToList();

            return menu;
        }

    }
}