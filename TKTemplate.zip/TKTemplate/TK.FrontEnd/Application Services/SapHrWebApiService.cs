﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using $safeprojectname$.Models;

namespace $safeprojectname$.Application_Services
{
    public class SapHrWebApiService
    {

        /// <summary>
        ///  Obtiene el usuario de SAP y datos relacionados a partir de los parámetros utilizados como filtro,en este caso por nombres de usuario(logon). 
        /// </summary>
        /// <param name="nombreUsuario"></param>
        /// <param name="login"></param>
        /// <param name="fecha"></param>
        /// <returns></returns>
        public UsersService.userInfo.FuncionModel obtenerFuncionPersonal(string nombreUsuario, string login, string fecha)
        {

            //Añadimos los parámetros de búsqueda
            StringBuilder webUrl = new StringBuilder(System.Configuration.ConfigurationManager.AppSettings["urlApiSAPHR"]);
            webUrl.Append("?");
            webUrl.Append("tipoRespuesta=1");
            webUrl.Append("&modoConsulta=" + System.Configuration.ConfigurationManager.AppSettings["modoConsultaUsuarios"]);
            webUrl.Append("&nombresUsuario=" + nombreUsuario);
            webUrl.Append("&login=" + login);
            webUrl.Append("&fecha=" + fecha);

            string jsonObject = string.Empty;
            using (HttpClient httpClient = new HttpClient(new HttpClientHandler { UseDefaultCredentials = true }))
            {
                httpClient.BaseAddress = new Uri(webUrl.ToString());
                httpClient.DefaultRequestHeaders.Accept.Clear();

                // Agrega el header Accept: application/json para recibir la data como json  
                httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                System.Threading.Tasks.Task<string> response = httpClient.GetStringAsync(webUrl.ToString());

                // Esperamos a que llegue la respuesta a la invocación
                while (!response.IsCompleted && !response.IsFaulted && !response.IsCanceled)
                { continue; }

                string objJson = response.Result;
                List<FuncionesSAPHRModel> listado = JsonConvert.DeserializeObject<List<FuncionesSAPHRModel>>(objJson.ToString());

                return listado.Select(x => new UsersService.userInfo.FuncionModel
                {
                    IdFuncion = x.IdFuncion,
                    Funcion = x.Funcion,
                }).FirstOrDefault();
            }
        }

        public string obtenerCorreoUsuario(string idUsuario)
        {
            //Añadimos los parámetros de búsqueda
            StringBuilder webUrl = new StringBuilder(System.Configuration.ConfigurationManager.AppSettings["urlApiSAPHR"]);
            webUrl.Append("?");
            webUrl.Append("tipoRespuesta=1");
            webUrl.Append("&modoConsulta=" + System.Configuration.ConfigurationManager.AppSettings["modoConsultaUsuarios"]);
            webUrl.Append("&nombresUsuario=" + idUsuario);
            webUrl.Append("&login=" + idUsuario);
            webUrl.Append("&fecha=" + DateTime.Now.ToString("yyyyMMdd"));

            string jsonObject = string.Empty;
            using (HttpClient httpClient = new HttpClient(new HttpClientHandler { UseDefaultCredentials = true }))
            {
                httpClient.BaseAddress = new Uri(webUrl.ToString());
                httpClient.DefaultRequestHeaders.Accept.Clear();

                // Agrega el header Accept: application/json para recibir la data como json  
                httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                System.Threading.Tasks.Task<string> response = httpClient.GetStringAsync(webUrl.ToString());

                // Esperamos a que llegue la respuesta a la invocación
                while (!response.IsCompleted && !response.IsFaulted && !response.IsCanceled)
                { continue; }

                string objJson = response.Result;
                List<FuncionesSAPHRModel> listado = JsonConvert.DeserializeObject<List<FuncionesSAPHRModel>>(objJson.ToString());

                return listado.Select(x => x.Email).FirstOrDefault();
            }
        }

        /// <summary>
        /// Obtiene los usuarios de SAP a partir de los parámetros utilizados como filtro. Cada parámtro puede incluir más de un valor separado por una coma (,), con excepción de la fecha.
        /// </summary>
        /// <param name="codigoEmpresa">Identificadores de empresa</param>
        /// <param name="ceco">Identificadores de centros de coste</param>
        /// <param name="division">Identificadores de división</param>
        /// <param name="subdivision">Identificadores de subdivisión</param>
        /// <param name="idDireccionTerritorial">Identificadores de dirección territorial</param>
        /// <param name="delegacion">Identificadores de delegación</param>
        /// <param name="fecha">Fecha para el que los usuarios están activos</param>
        /// <returns></returns>
        public List<UsuariosModel> GetUsers(string codigoEmpresa, string ceco, string division, string subdivision, string direccionArea, string funcion, string idDireccionTerritorial, string delegacion, string login, string fecha)
        {
            //La delegación en SAP es de tamaño 2 en lugar de 3 de MEDEA
            //Quito el 0 de la izquierda
            if (!string.IsNullOrEmpty(delegacion))
                delegacion = delegacion.TrimStart('0').PadLeft(2, '0');

            List<UsuariosModel> lstResultante = new List<UsuariosModel>();

            StringBuilder webUrl = new StringBuilder(System.Configuration.ConfigurationManager.AppSettings["urlApiSAPHR"]);
            webUrl.Append("?");
            webUrl.Append("tipoRespuesta=1");
            webUrl.Append("&modoConsulta=" + System.Configuration.ConfigurationManager.AppSettings["modoConsultaUsuarios"]);
            webUrl.Append("&codigosEmpresa=" + codigoEmpresa);
            webUrl.Append("&codigosCentroCoste=" + ceco);
            webUrl.Append("&idsDivision=" + division);
            webUrl.Append("&idsSubdivision=" + subdivision);
            webUrl.Append("&idsDireccionArea=" + direccionArea);
            webUrl.Append("&funciones=" + funcion);
            webUrl.Append("&idsDireccionTerritorial=" + idDireccionTerritorial);
            webUrl.Append("&idsDelegacion=" + delegacion);
            webUrl.Append("&login=" + login);
            webUrl.Append("&fecha=" + fecha);

            string jsonObject = string.Empty;
            using (HttpClient httpClient = new HttpClient(new HttpClientHandler { UseDefaultCredentials = true }))
            {
                httpClient.BaseAddress = new Uri(webUrl.ToString());
                httpClient.DefaultRequestHeaders.Accept.Clear();

                // Agrega el header Accept: application/json para recibir la data como json  
                httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

                System.Threading.Tasks.Task<string> response = httpClient.GetStringAsync(webUrl.ToString());

                // Esperamos a que llegue la respuesta a la invocación
                while (!response.IsCompleted && !response.IsFaulted && !response.IsCanceled)
                { continue; }

                string objJson = string.Empty;

                if (response.IsCompleted && !response.IsCanceled)
                {
                    objJson = response.Result;
                }
                lstResultante = JsonConvert.DeserializeObject<List<UsuariosModel>>(objJson.ToString());
            }

            foreach (UsuariosModel itemUser in lstResultante)
            {
                itemUser.Nombre = itemUser.NombreCompleto;
                itemUser.Añadido = "AUTOMATICO";
            }

            return lstResultante;
        }
    }       
}