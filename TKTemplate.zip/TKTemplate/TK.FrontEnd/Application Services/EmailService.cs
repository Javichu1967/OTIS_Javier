﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Web;
using TK.Repository;
using $safeprojectname$.Models;

namespace $safeprojectname$.Application_Services
{
    public class EmailService
    {
        /// <summary>
        /// Método que envía el email con la incidencia
        /// </summary>
        /// <param name="nombreUsuario"></param>
        /// <param name="emailUsuario"></param>
        /// <param name="descripcionIncidencia"></param>
        /// <param name="codigoApp"></param>
        /// <param name="nombreApp"></param>
        /// <param name="fichero"></param>
        /// <returns></returns>
        public string EnviarEmail(string loginUsuario, string nombreUsuario, string emailUsuario, string emailCAU, string codApp, string nombreApp, string descripcionIncidencia, string path)
        {
            try
            {
                List<string> listaEmailUser = new List<string>();
                listaEmailUser.Add(emailUsuario);

                MonitorizacionCorreoModel modelCorreo = new MonitorizacionCorreoModel
                {
                    CodigoAplicacion = codApp,
                    NombreAplicacion = nombreApp,
                    EmailFrom = emailUsuario,
                    EmailTo = emailCAU,
                    EmailsCC = ConfigurationManager.AppSettings["Entorno"].ToLower().Equals("pruebas") 
                                ? (ConfigurationManager.AppSettings["emailsCC"] != "" ? ConfigurationManager.AppSettings["emailsCC"].Split(';').ToList() : new List<string>()) 
                                : listaEmailUser,
                    EmailsCCO = ConfigurationManager.AppSettings["emailsCCO"] != "" ? ConfigurationManager.AppSettings["emailsCCO"].Split(';').ToList() : new List<string>(),
                    AsuntoEmail = "INCIDENCIA " + codApp + " - " + nombreApp ,
                    CuerpoEmail = "Por favor, asignar la incidencia a <b>DESARROLLO INTRANET</b>. <br/><br/> <u>Descripción de la incidencia</u> :  <br/><br/>" + descripcionIncidencia.Trim(),
                    FechaEnvioCorreo = DateTime.Now,
                    LoginUsuario = loginUsuario,
                    UsuarioCreacion = nombreUsuario,
                    FechaActualizacion = DateTime.Now,
                    UsuarioModificacion = nombreUsuario,
                    Prioridad = ConfigurationManager.AppSettings["prioridad"],
                    UrlApp = ConfigurationManager.AppSettings["urlApp"] != "" ? ConfigurationManager.AppSettings["urlApp"] : "",
                    Path = path
                };

                string respuesta = RepositorioWebApiService.GuardarLogCorreo(modelCorreo);

                if (respuesta.Contains("OK"))
                {
                    string resultado = RepositorioWebApiService.EnviarEmail(modelCorreo);

                    if (resultado.Contains("OK"))
                    {
                        return "Success";
                    }
                    else
                    {
                        return "Error";
                    }                  
                }
                else
                {
                    return "Error";
                }
            }
            catch (Exception ex)
            {
                return "Error";
            }
        }
    }
}